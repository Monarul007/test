============================
Rule set ``@PHP54Migration``
============================

Rules to improve code for PHP 5.4 compatibility.

Rules
-----

- `array_syntax <./../rules/array_notation/array_syntax.rst>`_
  config:
  ``['syntax' => 'short']``
