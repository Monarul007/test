<?php

class PhakeTest_PDOExtendingClass extends PDO
{
}
