<?php
/**
 * Created by JetBrains PhpStorm.
 * User: mikel
 * Date: 11/25/11
 * Time: 10:09 PM
 * To change this template use File | Settings | File Templates.
 */

class Phake_Exception_VerificationException extends Exception
{

}
