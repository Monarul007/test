<?php
namespace PhakeTest;

/**
 * Class that is namespaced.
 *
 * @author Brian Feaver <brian.feaver@sellingsource.com>
 */
class NamespacedClass
{
}
