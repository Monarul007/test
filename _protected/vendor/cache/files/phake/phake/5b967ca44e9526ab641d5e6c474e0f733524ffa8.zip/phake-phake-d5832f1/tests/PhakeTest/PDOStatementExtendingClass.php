<?php

class PhakeTest_PDOStatementExtendingClass extends PDOStatement
{
    protected function __construct()
    {
    }
}
