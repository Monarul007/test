<?php
namespace PhakeTest;

/**
 * Just what it says.
 *
 * @author Brian Feaver <brian.feaver@sellingsource.com>
 */
class AnotherNamespacedClass
{

}
