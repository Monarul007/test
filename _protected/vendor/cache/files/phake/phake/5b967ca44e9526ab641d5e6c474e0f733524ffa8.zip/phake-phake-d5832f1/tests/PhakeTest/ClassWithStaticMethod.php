<?php

class PhakeTest_ClassWithStaticMethod 
{
    public static function ask() {
        return 'Asked';
    }
}
